package com.example.prototype2;
import android.content.Intent;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
    public void submitButton(View v)
    {
        Intent getActivity3Intent = new Intent(this, MainActivity3.class);

        //Here save data entered by user - data will be sent to server

        startActivity(getActivity3Intent);


    }




}