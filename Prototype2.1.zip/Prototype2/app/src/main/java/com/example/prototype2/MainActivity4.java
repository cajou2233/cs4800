package com.example.prototype2;
import android.content.Intent;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
    }

    public void repeatButton(View view)
    {
        //Return to first page
        Intent returnToMainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(returnToMainActivityIntent);
    }

    public void exitButton(View view)
    {
        //User is finished with application
        finish();
        System.exit(0);
    }
}