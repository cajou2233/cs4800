package com.example.prototype2;
import android.view.View;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    /** Called when the user touches the button */
    public void nextButton(View view)
    {
        Intent getSymptomsActivityIntent = new Intent(this, SymptomsActivity.class);

        //Here save the data entered by user - data will be sent to server

        startActivity(getSymptomsActivityIntent);
    }
}